// Monster Hunter: World Mod Manager Extension
// Interacts with ModTogether ModAPI

function getStatePath(gameDir) {
    return API.CombinePath(gameDir, "GameMods/mhw_installed_mods.json");
}

function loadState(gameDir) {
    var content = API.ReadState(getStatePath(gameDir));
    if (!content) return {};
    try {
        return JSON.parse(content);
    } catch(e) {
        return {};
    }
}

function saveState(gameDir, state) {
    API.SaveState(getStatePath(gameDir), JSON.stringify(state, null, 2));
}

function installMod(archivePath, gameDir, specificFiles) {
    var modName = archivePath.substring(archivePath.lastIndexOf("\\") + 1);
    API.Log("Extracting " + modName + " to nativePC...");

    var nativePcPath = API.CombinePath(gameDir, "nativePC");
    var extractedFiles = [];

    // Convert JS array to C# list-like array if it has elements
    var csharpSpecificFiles = null;
    
    // We assume API.ExtractArchive returns a list of relative file paths that were extracted.
    // But since MHW mods can be packaged in many ways (with or without 'nativePC/' root),
    // we extract to a temp folder first, then find the 'nativePC' folder or move contents directly.
    var tempFolder = API.CombinePath(API.CombinePath(gameDir, "GameMods"), ".temp_extract");
    API.CreateDirectory(tempFolder);
    
    // Extract everything to temp
    var allFiles = API.ExtractArchive(archivePath, tempFolder, null);
    
    var state = loadState(gameDir);
    var modFilesTracked = [];

    // Move files from temp to gameDir/nativePC
    for (var i = 0; i < allFiles.Count; i++) {
        var relPath = allFiles[i];
        
        // Skip if specificFiles was provided and this file isn't in it
        if (specificFiles && specificFiles.length > 0) {
            var found = false;
            for (var j = 0; j < specificFiles.length; j++) {
                if (relPath === specificFiles[j] || relPath.indexOf(specificFiles[j] + "/") === 0) {
                    found = true; break;
                }
            }
            if (!found) continue;
        }

        var sourceFile = API.CombinePath(tempFolder, relPath);
        var targetFile = "";
        var trackPath = "";

        // Standardize path separators
        relPath = relPath.replace(/\\/g, "/");

        // Logic to strip 'nativePC' from path if the mod author included it
        if (relPath.toLowerCase().indexOf("nativepc/") === 0) {
            trackPath = relPath.substring(9);
        } else {
            trackPath = relPath;
        }
        
        targetFile = API.CombinePath(nativePcPath, trackPath);
        
        // Move file
        API.MoveFile(sourceFile, targetFile, true);
        modFilesTracked.push(trackPath);
    }

    // Save tracking
    state[modName] = modFilesTracked;
    saveState(gameDir, state);

    // Cleanup temp
    API.DeleteDirectory(tempFolder, true);
    
    API.Log("✅ Installed " + modName);
}

function uninstallMod(modName, gameDir) {
    API.Log("Uninstalling " + modName + "...");
    var state = loadState(gameDir);
    
    if (state[modName]) {
        var nativePcPath = API.CombinePath(gameDir, "nativePC");
        var files = state[modName];
        
        for (var i = 0; i < files.length; i++) {
            var targetFile = API.CombinePath(nativePcPath, files[i]);
            API.DeleteFile(targetFile);
        }
        
        delete state[modName];
        saveState(gameDir, state);
        API.Log("🗑️ Uninstalled " + modName);
    } else {
        API.Log("Mod " + modName + " is not installed.");
    }
}
